<?php

  // connessione database sql
  $servername = "localhost";
  $dbname = "gestione_personale";
  $username = "root";
  $password = "";

?>